# weapon-detection > 2023-03-09 12:10pm
https://universe.roboflow.com/maheshchhetri/weapon-detection-e6otc

Provided by a Roboflow user
License: CC BY 4.0

